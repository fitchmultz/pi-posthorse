# Final issue 102 measurement, 2026-10-24

This supersedes the primary numbers in MEASUREMENTS.md and the additional fork numbers in VERIFICATION.md. Those files and failed/earlier attempts remain historical evidence. Source is admission baseline `8ac3eed9d6326e31e97ba9a1b7288c7568084777` plus `final-treatment.patch`; `final-source-sha256.txt` identifies production source bytes. Both runtime hosts are independently resolved and fully qualified on the earlier revision before the final same-target memo correction. Final-revision qualification is tracked separately and is not asserted by this snapshot.

## Final data shape and correction

The existing per-search ID map starts with native projected message arrays. A candidate ID converts that value to normalized joined text at most once. Subsequent context-edit candidates sharing the same target reuse that string. The map is owned by one historyMatches invocation and discarded afterward. It has no cross-search identity, array-length, wallclock, branch-generation or invalidation heuristic. Pi still computes the canonical projection and edit/compaction semantics. All-session projection captures invocation-time visibility before archive I/O; default no-match searches avoid projection entirely.

A real native persisted-journal test exposed repeated-target work in the earlier candidate-only version. Eight edits of one native assistant entry caused ten serializations of the last projected argument object for branch search and eight for all-session search. `shared-target-red.log` records both failures. The final map retains normalized text once, preserving the baseline ceilings of three serializations for branch search and one for all-session search. Eight active edits are excluded in each scope. The passing test is `shared-target-green.log`; the source test adds an actual diagnostic to later full-suite runs.

## Method

The same `search-bench.mjs`, valid preserved 37,225,425-byte v3 journal and known-usage tool configuration described in MEASUREMENTS.md were used. The timed region is the complete registered history tool executor, not just a helper. Opening/registration and forced GC occur outside it. No provider is called. Timing runs use no counter patch, preservation import, profiler or tracer. Each of five fresh A/B process pairs runs no-match, first matching page, then its cursor continuation. Each source tree resolves runtime imports through that host's exact coherent dependency graph. Settings, cache order, Node 24.22.1 binary and flags are identical within a host. Task-local npm 12.2.0 is used for required acceptance/qualification, not inside the timed region. Native host APIs were inspected on official floor 1.3.0, latest official 1.4.0 and fork main c17adbc400319887c5ab34fce1ed2a59be746da4 before choosing this local design.

`final-{official,fork}-load.txt` records load, two cores and process state before each host's samples. No compiler or other CPU worker was active. The nonzero load averages reflect recently completed test/qualification work; each side is interleaved to share residual drift. This is synthetic Debian Linux x64 proof, not owner-corpus, installed macOS, native Windows, provider latency, startup or every-turn proof.

## Results

Every one of the 60 timed requests returned the exact expected outputs with zero errors. All paired output hashes, counts, skipped active-control counts and cursors agree. The journal's size and mtime remained unchanged. Raw sample directories are `final-official-pairs/` and `final-fork-pairs/`; `final-summary.json` retains every value.

| Host and registered executor | Baseline median [range], ms | Final median [range], ms |
| --- | --- | --- |
| Official no-match | 284.273 [267.559, 331.848] | 158.567 [153.022, 159.577] |
| Official first page | 211.494 [202.932, 217.364] | 126.119 [117.048, 150.282] |
| Official second page | 210.128 [191.873, 232.760] | 116.767 [109.972, 120.851] |
| Fork no-match | 290.494 [274.067, 329.367] | 155.508 [150.153, 157.699] |
| Fork first page | 201.014 [193.032, 216.522] | 114.328 [112.817, 120.185] |
| Fork second page | 206.329 [184.222, 213.970] | 114.772 [95.844, 118.252] |

The primary official no-match median is 44.2% lower. All before/after latency ranges are disjoint. These are within-host comparisons; no cross-host speed comparison is claimed.

Median live-heap increase at executor return is 90,566,656 to 50,413,360 bytes for official no-match and 90,008,224 to 52,288,208 bytes for fork no-match. This is not total allocation or peak heap. The JSON contains post-GC JS-heap deltas separately from process RSS. Post-GC RSS is not retained JS heap. No private-corpus memory reduction is inferred.

## Limiter and work

Separate `final-{official,fork}-{A,B}.cpuprofile` and `final-{official,fork}-work-{A,B}/` runs profile and instrument real work; none contributes a reported time sample. Both hosts reduce argument-object serialization from 8,192 to 4,096 calls, representing 52,838,400 to 26,419,200 public payload bytes, on each case. No-match native projection calls drop from one to zero. Matching calls still construct one authoritative native projection. All-session searches still capture native projection once before I/O, even with no match. No claim removes that remaining allocation.

CPU profile frames and counters identify duplicate JSON serialization, text normalization and related garbage collection as the removed work. The remaining branch scan and serialization/matching dominate. Roughly one duplicate pass disappears, consistent with the measured change; this is not constant-time search or a fabricated full private-session speedup.

## Reproduction

The exact command shape is retained in MEASUREMENTS.md. Substitute `final-official-pairs/$i-$side` and the frozen official SDK, or `final-fork-pairs/$i-$side` and `/workspace/hosts/fork-c17adbc4-frozen/node_modules/@earendil-works/pi-coding-agent/dist/index.js`. Before each host, both detached source worktrees' node_modules symlinks point to the same frozen host graph. Baseline worktree is unchanged main; treatment copies only the changed production history-search file. Run each side five times in alternating A,B order with the same generated journal and `node --expose-gc ... timing`. Run separate `work` mode with `--cpu-prof` for counters/profiles. No raw private corpus or request log was used or sanitized.
