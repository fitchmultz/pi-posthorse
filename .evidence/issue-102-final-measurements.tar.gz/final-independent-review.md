# Issue 102 final independent delta review

## Verdict

**No actionable findings.** I found no production correctness defect or new test-fixture defect in the reviewed revision. The shared-target fix is a minimal completion of candidate-only projected-text normalization. The earlier vacuous all-session replacement assertion is fixed.

This is an independent, report-only review using the same configured inherited model. It is not a diverse-model panel or an independent test-suite execution. Root retains ownership of branch and PR 104.

## Reviewed revisions

The checkout was `/workspace/issue-102`. Its committed HEAD was `5e2c0ffdf04ba3a21e467109a4fdd8c9ad7ed662` throughout this review.

I reviewed both the working-tree delta from that commit and the complete production change from baseline `8ac3eed9d6326e31e97ba9a1b7288c7568084777`. The only production file changed against the baseline is `src/history-search.ts`.

Final reviewed source identities are SHA-256.

| Artifact | SHA-256 |
| --- | --- |
| `src/history-search.ts` | `6a34d3b9104b549323a47034628740200b0b86c028d569bb86d723eb3b9d14a5` |
| `test/native.test.mjs` | `f0ff9d0a75fe0a6e16486880f6397f0702cd082c3484e45d725fb6dc0ba843fb` |
| Source and test diff from committed HEAD | `bfd466a8c65d4d02a68fc837b5d98391064d2c1705e3e2d2b0d2c7a7a06fd3c1` |
| Production diff from baseline | `1dcdb917b5b120560e874b64ebf55341d0e1f77911e496eaf7795d0c06e25b9e` |
| Source and test diff from baseline | `9347273e19eff4948c0e917c39b6245618ab66c0b0dc29521adccbe55846f734` |

Root updated `docs/performance.md` while this review was in progress. I read its revised scope language, but did not audit the rerunning benchmark samples or certify the numerical results. The final test identity above includes the newly added serialization-count diagnostic.

## Production assessment

The data shape is one invocation-local map from projected source-entry ID to either native messages awaiting normalization or their normalized string. `src/history-search.ts:85-109` contains the entire mutable owner. It does not mutate the native messages, add a second map, share state across calls, or introduce invalidation machinery.

- At lines 100-103, only `undefined` denotes absence. A cached empty string remains present. The final `includes` retains the baseline empty-string semantics.
- Lines 93-96 retain the original eligibility filter. Missing and empty IDs and empty native message arrays are not indexed. Duplicate IDs keep the last eligible projected row, just as the original `Map` construction did. An ineligible later duplicate does not erase an earlier eligible row.
- Line 99 still resolves a `context_edit` candidate through `targetId`. Every edit referring to the same target therefore reaches the same map slot.
- Lines 104-106 normalize an eligible slot once and replace only that slot with a string. Repeated candidates reuse that result. Candidate-side normalization remains necessary and is not claimed to disappear.
- Line 105 retains `messages.map(seenText).join("\n")` exactly. Native compaction entries may contribute both a system message and a summary. Their joined visibility text remains unchanged.
- The reminder exception remains ahead of lazy map construction at lines 88-90.

The all-session snapshot at lines 311-313 remains correct. It captures native projection before archive I/O and does not rebuild it after later edits. An empty projection array is also retained because the fallback uses nullish coalescing, not a length or truthiness check. Default branch searches contain no intervening await before visibility checks, so their delayed projection does not create the asynchronous timing window covered by the snapshot test.

I inspected the actual installed official session-manager implementation, the identical latest-official packaged implementation, and the pinned fork's projection implementation. Native projection selects edits and compaction and builds new projection rows and message arrays. Edit projection returns a new message wrapper rather than modifying a previously returned projection. The fork caches ancestry, not the Posthorse normalization map. This supports invocation-local reuse without depending on a projection object's identity across calls.

The snapshot reasoning assumes native append/edit/branch APIs and the repository's readonly source contract. Deliberate in-place mutation of previously returned native message payloads during an outstanding search was not tested or newly supported.

Current-file-only active visibility in `all=true` searches is unchanged. Other session files do not become hidden merely because they contain the same ID. Ranking, lookahead, cursor decoding and progress, page reservations, page rendering and skipped-count accumulation are unchanged. No new await, catch, retry, abort guard or cleanup path was introduced. I found no changed cancellation or error-identity handling in the reviewed code, but did not execute cancellation scenarios.

## Test assessment

The new regression at `test/native.test.mjs:394-422` exercises the extension's registered native history executor through `loadedHistory`. It creates a real persisted `SessionManager`, appends an assistant message, and applies eight native edits to one target. It does not supply a manufactured projection or compute its expected result from the implementation under review.

The assertions require no returned history matches and exactly eight skipped candidates. They therefore establish that the matching edits were scanned and excluded, rather than allowing an empty archive to satisfy the serialization budget. Both scopes run the same fixture. In the all-session case, raw candidates are parsed from the native journal.

The serialization counter identifies the final projected argument object. Native `fauxToolCall` retains that object, native edit storage retains the replacement content, and native projection preserves that content reference. Mocking begins after fixture persistence. The counter therefore observes the repeated projected-target conversion rather than setup writes. The default budget permits the existing raw-candidate and candidate-comparison work in addition to one projected conversion. The archive budget isolates the one projected conversion because parsed archive candidates have distinct object identities.

The supplied `shared-target-red.log` records both regressions failing on the actual local 1.3.0 host, with 10 serializations against budget 3 and 8 against budget 1. `shared-target-green.log` records both regressions, the invocation-snapshot test and both lifecycle scopes passing, five tests in total. These are root's recorded executions, not mine. The final diagnostic-only test addition occurred after the green log I read.

The repaired replacement fixture now uses `SessionManager.create` in a separate replacement directory, appends a matching user message and an assistant message, and requires `replacement.details.skipped === 1` at lines 504-509. Native persistence writes that conversation to a real file. The all-session assertion can no longer pass by enumerating no candidates. The prior finding is closed.

The snapshot and lifecycle tests continue to cover native edits, omission, restoration, branching, compaction, rollover, reopening, journal replacement and manager replacement. I inspected their assertions without rerunning them.

## Verification and limits

Performed independently.

- Read the requested Pi adapter, poteto skill, delegate profile, repository `AGENTS.md`, `docs/quality.md`, and previous independent report.
- Inspected every changed production and test hunk and the surrounding source, native projection, persistence, archive scanning and pagination contracts.
- Read the shared-target red/green logs and root's final memo lint, format and compiler logs. The latter record clean lint, formatting and compiler runs. I did not independently execute them.
- Ran `node --check test/native.test.mjs` and `git diff --check` after the final diagnostic addition. Both exited successfully.
- Rechecked the reviewed source/test hashes and committed HEAD.

Not performed by this reviewer.

- Native or unit test suites, `npm run verify`, lint, format, compiler, package or host-qualification gates.
- Benchmarks, profiling, CPU-heavy builds or installations. Root's measurement hold was respected.
- GitHub mutations, deployment, active-runtime access, private journal access, credential access or local-device access.

I made no production or test edits. My only deliverable write is this report. No nested program, delegate or model switch was used.

The Laziness Protocol favored the single-map update over an additional cache owner. Model the Domain supported the native-messages-or-normalized-string state in that existing per-search map. Test Behavior, Not Implementation required real scanned candidates and discriminating skipped counts before closing the earlier fixture finding.
