# Fork preparation status

Preparation completed at `2026-10-24T16:36:36Z`. Compilation remains held for the coordinator's native quality-checker build. No source file changed.

The maintained fork is `/workspace/hosts/fork-c17adbc4`, clean at `c17adbc400319887c5ab34fce1ed2a59be746da4`. Automation is `/workspace/hosts/automation-54c68722`, clean at `54c687228d840506555801b9db038373e697d901`.

## Prepared inputs

- Node reports `v24.22.1`.
- The task-local npm reports `12.2.0`, the exact `packageManager` in pinned automation. It does not replace the global npm.
- `npm ci --ignore-scripts` passed and installed 339 packages.
- `npm run hydrate:model-data` passed with strict public-data fetching. It changed only ignored provider JSON data.
- `npm run check:model-data` passed.
- `tsc --version` reports `7.0.2`. `esbuild --version` reports `0.28.2`. These checks did not compile source.
- The fork contains tracked native TUI prebuilds for Linux, macOS, and Windows on x64 and arm64. Their hashes are in `admission-attempt-2.log`.
- The fork's declared runtime cohort adds `@earendil-works/chord` and `@earendil-works/pi-durable` at `1.4.0`. The fork declares TypeBox `1.3.37`. The packed runtime still needs physical verification.

The installer logs retain an `EBADENGINE` warning from the development-only `autoevals@0.3.0` package and deprecation warnings. No source dependency or lock changed.

## Input hashes

| Input | SHA-256 |
| --- | --- |
| Fork `package.json` | `cf6790211fc1b3c0d61d86ea860cb9c1cb3c043f97d1993fa9d9b1e9257b367c` |
| Fork `package-lock.json` | `64ce3f10abc70d4a0d03319216b024ab21825717d2c3a643956e59c05e24b32e` |
| Source installer `package.json` | `9792b34aba5a94320fde5c68600eac4a5720d0d63ebc527d462bd125665b29ee` |
| Source installer `package-lock.json` | `bcd91368ae31e73cc17946c79e9279467c19c432c1e6df475ee07521cbc766e8` |
| Hydrated model-data `.manifest.json` | `a9a320fcf5adf1c2d6d27088142889bad21d5025eea1ad6f4f77dbe60a3f3d8f` |

## Pending command after explicit CPU release

The prepared command is not yet executed.

```bash
env -i PATH=/usr/local/bin:/usr/bin:/bin LANG=C.UTF-8 \
  FORK_BUILD_RELEASED=1 \
  bash /workspace/evidence/issue-102/fork-prep/build-and-pack.sh \
  > /workspace/evidence/issue-102/fork-prep/build-and-pack-attempt-1.log 2>&1
```

The script verifies clean exact source and inputs before compilation. It sets isolated HOME, temporary, npm-config, and agent directories under `/var/tmp/fph-419`. It uses the local npm `12.2.0`, `PI_OFFLINE=1`, `PI_TELEMETRY=0`, and `GOMAXPROCS=2`.

The actual build and pack commands inside the script are:

```bash
cd /workspace/hosts/fork-c17adbc4
npm run build:offline
node /workspace/hosts/automation-54c68722/scripts/pack-fork.mjs \
  /workspace/hosts/fork-c17adbc4 \
  /workspace/hosts/fork-package-c17adbc4 \
  c17adbc400319887c5ab34fce1ed2a59be746da4
```

The fork's native build scheduler runs at most two workspace builds concurrently. The public model hydration has already completed. The offline build uses validated local model JSON. Its script does not rebuild TUI native prebuilds or compile the Rust environment daemon.

Packing uses automation's exact source-cleanliness, installer-lock, native artifact, and receipt mechanism. The packer creates `/workspace/hosts/fork-package-c17adbc4`, which must not already exist.

After packing, `inspect-packed-host.mjs` calls the pinned automation `prepareHost()` helper for an independent packed runtime at `/workspace/hosts/fork-c17adbc4-frozen`. That dependency installation uses the public npm registry and no provider credentials. The helper verifies the receipt and the physical cohort. The probe then asserts TypeBox `1.3.37`, chord, durable, and the remaining `1.4.0` companions.

The actual packed CLI runs `--offline --version` under an isolated HOME and short temporary root at `/var/tmp/fpk-419`, outside project-marker ancestry. The script writes SDK entry, declarations, CLI, package artifact, receipt, source installer, runtime lock, native prebuild, and physical runtime graph hashes to `fork-packed-identity.json`.

## Current verification limits

No package `dist` directory exists yet. No fork pack, physical installed fork runtime, SDK artifact identity, or actual CLI output exists yet. Source and dependency preparation do not qualify Posthorse compatibility.

The full qualifier remains held for the integrated root revision and corrected native-checker caches. No `qualify.mjs`, Posthorse implementation, production edit, merge, push, PR operation, local-device access, private configuration access, runtime activation, or account-setting change occurred.

Both scripts pass `bash -n`. The identity probe passes `node --check`. These are syntax checks only.

The first preparation attempt failed before installation because npm rejects the same `/dev/null` path for both global and user configuration. `admission-attempt-1.log` preserves that failure. The second attempt used separate empty isolated configuration files and passed. No TLS validation was disabled.

## Applied principles

Prove It Works keeps actual packed CLI execution and physical companion identity as pending checks, rather than treating source inspection as qualification. Separate Before Serializing Shared State keeps evidence and build outputs away from the coordinator's production worktree. The coordinator retains the explicit CPU-release gate.
