#!/usr/bin/env bash
set -euo pipefail
if [[ "${FORK_BUILD_RELEASED:-}" != 1 ]]; then
  printf '%s\n' 'Build held. The coordinator must explicitly release the CPU hold.' >&2
  exit 2
fi
EVIDENCE=/workspace/evidence/issue-102/fork-prep
SOURCE=/workspace/hosts/fork-c17adbc4
AUTOMATION=/workspace/hosts/automation-54c68722
OUTPUT=/workspace/hosts/fork-package-c17adbc4
EXPECTED=c17adbc400319887c5ab34fce1ed2a59be746da4
ATTEMPT=${FORK_BUILD_ATTEMPT:-1}
ISOLATED=/var/tmp/fph-419
export HOME="$ISOLATED/home" TMPDIR="$ISOLATED/tmp" PI_CODING_AGENT_DIR="$ISOLATED/agent"
export XDG_CONFIG_HOME="$ISOLATED/home/config" XDG_CACHE_HOME="$ISOLATED/home/cache" XDG_DATA_HOME="$ISOLATED/home/data"
export PATH="$EVIDENCE/npm-tool/node_modules/.bin:$PATH"
export npm_config_cache="$EVIDENCE/npm-cache" npm_config_userconfig="$ISOLATED/user.npmrc" npm_config_globalconfig="$ISOLATED/global.npmrc"
export npm_config_audit=false npm_config_fund=false NODE_OPTIONS=--use-system-ca
export PI_OFFLINE=1 PI_SKIP_VERSION_CHECK=1 PI_TELEMETRY=0 GOMAXPROCS=2 CI=true
cd "$SOURCE"
[[ "$(git rev-parse HEAD)" == "$EXPECTED" ]]
[[ "$(git -C "$AUTOMATION" rev-parse HEAD)" == 54c687228d840506555801b9db038373e697d901 ]]
[[ -z "$(git status --porcelain)" ]]
[[ "$(npm --version)" == 12.2.0 ]]
[[ ! -e "$OUTPUT" ]]
[[ ! -e "$EVIDENCE/build-attempt-$ATTEMPT.log" ]]
[[ "$(sha256sum package-lock.json | cut -d ' ' -f1)" == 64ce3f10abc70d4a0d03319216b024ab21825717d2c3a643956e59c05e24b32e ]]
[[ "$(sha256sum packages/ai/src/providers/data/.manifest.json | cut -d ' ' -f1)" == a9a320fcf5adf1c2d6d27088142889bad21d5025eea1ad6f4f77dbe60a3f3d8f ]]
{
  date -u +%FT%TZ
  npm run build:offline
  date -u +%FT%TZ
} > "$EVIDENCE/build-attempt-$ATTEMPT.log" 2>&1
{
  date -u +%FT%TZ
  node "$AUTOMATION/scripts/pack-fork.mjs" "$SOURCE" "$OUTPUT" "$EXPECTED"
  git diff --exit-code
  git status --porcelain
  date -u +%FT%TZ
} > "$EVIDENCE/pack-attempt-$ATTEMPT.log" 2>&1
node "$EVIDENCE/inspect-packed-host.mjs" > "$EVIDENCE/packed-host-attempt-$ATTEMPT.log" 2>&1
