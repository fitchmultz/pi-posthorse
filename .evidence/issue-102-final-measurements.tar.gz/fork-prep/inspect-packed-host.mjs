import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { existsSync, mkdirSync, realpathSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { isolatedEnvironment, readJson, sha256, writeJson } from "/workspace/hosts/automation-54c68722/scripts/common.mjs";
import { prepareHost } from "/workspace/hosts/automation-54c68722/scripts/hosts.mjs";

const evidence = dirname(fileURLToPath(import.meta.url));
const target = "/workspace/hosts/fork-package-c17adbc4";
const directory = "/workspace/hosts/fork-c17adbc4-frozen";
assert.equal(existsSync(directory), false, "Keep existing host installs and their logs intact");
const isolatedRoot = "/var/tmp/fpk-419";
const env = {
  ...isolatedEnvironment(isolatedRoot),
  PATH: `${evidence}/npm-tool/node_modules/.bin:/usr/local/bin:/usr/bin:/bin`,
  NODE_OPTIONS: "--use-system-ca",
  npm_config_cache: join(evidence, "npm-cache"),
};
const host = await prepareHost(directory, "fork", target, env);
assert.equal(host.version, "1.4.0");
assert.equal(host.companions.typebox, "1.3.37");
for (const name of ["chord", "pi-agent-core", "pi-ai", "pi-codemode", "pi-durable", "pi-mcp", "pi-telemetry", "pi-tui"]) {
  assert.equal(host.cohort[`@earendil-works/${name}`], "1.4.0", `Wrong fork companion ${name}`);
}
assert.equal(host.provenance.ref, "c17adbc400319887c5ab34fce1ed2a59be746da4");
for (const [name, resolved] of Object.entries(host.packageDirs)) {
  assert.ok(realpathSync(resolved).startsWith(`${directory}/node_modules/`), `Companion escaped the isolated packed graph ${name}`);
}
const runDirectory = join(isolatedRoot, "run");
mkdirSync(runDirectory, { recursive: true });
const args = [host.cli, "--offline", "--version"];
const result = spawnSync(process.execPath, args, {
  cwd: runDirectory,
  env,
  encoding: "utf8",
  timeout: 30_000,
  maxBuffer: 1024 * 1024,
});
writeFileSync(join(evidence, "cli-version.stdout.log"), result.stdout ?? "");
writeFileSync(join(evidence, "cli-version.stderr.log"), result.stderr ?? "");
writeJson(join(evidence, "cli-version-command.json"), {
  executable: process.execPath,
  args,
  cwd: runDirectory,
  isolatedHome: env.HOME,
  status: result.status,
  signal: result.signal,
  error: result.error?.message,
  offline: env.PI_OFFLINE === "1",
  telemetry: env.PI_TELEMETRY,
});
if (result.error) throw result.error;
assert.equal(result.status, 0, result.stderr);
assert.equal(result.stdout.trim(), "1.4.0");
const manifestFiles = Object.fromEntries(["receipt.json", "manifest.json", "package.json", "package-lock.json", "install-lock/package.json", "install-lock/package-lock.json"]
  .map((file) => [file, sha256(join(target, file))]));
const sdkFiles = Object.fromEntries(["package.json", "dist/index.js", "dist/index.d.ts", "dist/bundle/cli.js", "dist/core/session-manager.js", "dist/core/session-manager.d.ts"]
  .map((file) => [file, sha256(join(host.packageDir, file))]));
const nativeFiles = Object.fromEntries([
  "native/darwin/prebuilds/darwin-arm64/darwin-platform.node",
  "native/darwin/prebuilds/darwin-x64/darwin-platform.node",
  "native/linux/prebuilds/linux-arm64/linux-platform-x11.node",
  "native/linux/prebuilds/linux-x64/linux-platform-x11.node",
  "native/win32/prebuilds/win32-arm64/win32-platform.node",
  "native/win32/prebuilds/win32-x64/win32-platform.node",
].map((file) => [file, sha256(join(host.packageDirs["@earendil-works/pi-tui"], file))]));
writeJson(join(evidence, "fork-packed-identity.json"), {
  observedAt: new Date().toISOString(),
  automationRef: "54c687228d840506555801b9db038373e697d901",
  node: process.version,
  ...host,
  cliVersion: result.stdout.trim(),
  manifestFiles,
  sdkFiles,
  nativeFiles,
  receipt: readJson(join(target, "receipt.json")),
});
console.log(JSON.stringify({
  directory: host.directory,
  cohort: host.cohort,
  companions: host.companions,
  cliVersion: result.stdout.trim(),
  indexSha256: host.indexSha256,
  cliSha256: host.cliSha256,
  runtimeLockSha256: host.runtimeLockSha256,
  runtimeGraphSha256: host.runtimeGraphSha256,
}, null, 2));
