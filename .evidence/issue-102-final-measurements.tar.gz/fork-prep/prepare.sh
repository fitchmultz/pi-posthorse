#!/usr/bin/env bash
set -euo pipefail
EVIDENCE=/workspace/evidence/issue-102/fork-prep
SOURCE=/workspace/hosts/fork-c17adbc4
AUTOMATION=/workspace/hosts/automation-54c68722
ISOLATED=/var/tmp/fph-419
mkdir -p "$ISOLATED/home" "$ISOLATED/tmp" "$ISOLATED/agent" "$EVIDENCE/npm-cache"
export HOME="$ISOLATED/home" TMPDIR="$ISOLATED/tmp" PI_CODING_AGENT_DIR="$ISOLATED/agent"
export XDG_CONFIG_HOME="$ISOLATED/home/config" XDG_CACHE_HOME="$ISOLATED/home/cache" XDG_DATA_HOME="$ISOLATED/home/data"
: > "$ISOLATED/user.npmrc"
: > "$ISOLATED/global.npmrc"
export npm_config_cache="$EVIDENCE/npm-cache" npm_config_userconfig="$ISOLATED/user.npmrc" npm_config_globalconfig="$ISOLATED/global.npmrc"
export npm_config_audit=false npm_config_fund=false NODE_OPTIONS=--use-system-ca PI_TELEMETRY=0
cd "$SOURCE"
{
  date -u +%FT%TZ
  node --version
  npm --version
  git rev-parse HEAD
  git status --porcelain
  git -C "$AUTOMATION" rev-parse HEAD
  git -C "$AUTOMATION" status --porcelain
  sha256sum package.json package-lock.json packages/coding-agent/install-lock/package.json packages/coding-agent/install-lock/package-lock.json
  git ls-files 'packages/tui/native/*/prebuilds/*/*' | xargs sha256sum
} > "$EVIDENCE/admission-attempt-2.log" 2>&1
npm install --ignore-scripts --prefix "$EVIDENCE/npm-tool" npm@12.2.0 > "$EVIDENCE/npm-tool-install.log" 2>&1
export PATH="$EVIDENCE/npm-tool/node_modules/.bin:$PATH"
npm --version > "$EVIDENCE/reviewed-npm-version.log"
npm ci --ignore-scripts > "$EVIDENCE/npm-ci-attempt-1.log" 2>&1
npm run hydrate:model-data > "$EVIDENCE/hydrate-model-data-attempt-1.log" 2>&1
npm run check:model-data > "$EVIDENCE/check-model-data.log" 2>&1
{
  date -u +%FT%TZ
  git diff --exit-code
  git status --porcelain
  sha256sum package-lock.json packages/ai/src/providers/data/.manifest.json
} > "$EVIDENCE/prepared-source.log" 2>&1
