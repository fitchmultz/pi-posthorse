import assert from 'node:assert/strict';
import {execFileSync,spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {join} from 'node:path';
const cwd='/workspace/acceptance-102';
const out='/workspace/evidence/issue-102/rejection-probes';
mkdirSync(out,{recursive:true});
const target=join(cwd,'src/history-search.ts');
const original=readFileSync(target,'utf8');
const initialStatus=execFileSync('git',['status','--porcelain'],{cwd,encoding:'utf8'});
const cases=[
 {name:'syntactic',suffix:'\nexport const issue102Syntax = ;\n',expected:/Unexpected token|Expression expected|Expected an expression|parse|Parse/},
 {name:'semantic',suffix:'\nPromise.resolve("unowned async work");\n',expected:/no-floating-promises/},
 {name:'compiler',suffix:'\nexport const issue102Compiler: string = 102;\n',expected:/TS2322|not assignable to type/},
 {name:'formatting',suffix:'\nexport const issue102Formatting=  102;\n',expected:/formatting|Formatting/},
 {name:'allowance-isolation',suffix:'\nconst test = async (): Promise<void> => {};\ntest();\n',expected:/no-floating-promises/},
];
const results=[];
for(const item of cases) {
 try {
  writeFileSync(target,original+item.suffix);
  const command=['run','verify'];
  const run=spawnSync('npm',command,{cwd,env:process.env,encoding:'utf8',maxBuffer:64*1024*1024});
  const output=(run.stdout??'')+(run.stderr??'');
  writeFileSync(join(out,item.name+'.log'),output);
  assert.equal(run.error,undefined);
  assert.notEqual(run.status,0,`${item.name} must be rejected`);
  assert.match(output,item.expected,`${item.name} must fail for the intended diagnostic`);
  results.push({case:item.name,command:['npm',...command],status:run.status,signal:run.signal,expected:String(item.expected)});
 } finally {writeFileSync(target,original);}
}
writeFileSync(join(out,'results.json'),JSON.stringify(results,null,2)+'\n');
assert.equal(execFileSync('git',['status','--porcelain'],{cwd,encoding:'utf8'}),initialStatus);
console.log(JSON.stringify(results));
