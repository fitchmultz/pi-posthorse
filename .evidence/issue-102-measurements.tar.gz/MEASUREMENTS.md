# Issue 102 synthetic measurement, 2026-10-24

## Claim and scope

The registered default `history.search` executor does less duplicate active-context text work on this generated workload. This is Linux x64 synthetic tool-executor latency, not installed macOS, owner-corpus, provider, startup, or every-turn latency. The historical issue numbers are not these measurements.

Baseline is current-main admission `8ac3eed9d6326e31e97ba9a1b7288c7568084777`. `change.patch` and `source-sha256.txt` identify the treatment. Both sides import the same frozen latest-official 1.4.0 SDK and complete companion graph. `host-api/official-frozen-identity.json` retains its release installer lock, runtime lock, artifact identities and exact graph. The benchmark source worktrees resolve runtime imports through that host's node_modules. Node is 24.22.1, npm qualification uses 12.2.0, V8 13.6.233.17-node.58, Debian Linux x64, two available CPU cores. See `toolchain.json` and `lscpu.txt` for actual values rather than this prose if a version differs.

The data shape remains one per-invocation map from entry ID to native projected messages. No cross-search cache exists. Default searches defer native projection until a matching non-reminder candidate needs visibility. All-session searches retain the invocation-time native projection before archive I/O. Both paths normalize only candidate IDs. Matching searches and all-session searches still allocate native projection wrappers. Neither host exposes an edit-aware single-entry projector; see `host-api/REPORT.md` for API/source evidence and rejected alternatives.

## Workload and timed boundary

`generate.mjs` wrote the preserved valid version-3 journal `journals/synthetic-v3.jsonl`, SHA-256 `b2ebb51eda65765855ca791b2eb1e93d51f2725be8ad8b8ef0867f85e3ddd9c8`. It is 37,225,425 bytes and 12,291 physical lines, with 12,290 non-header entries. It contains 4,096 archived original user entries, a Posthorse compaction boundary, 4,096 active assistant tool calls with 6,450-byte public synthetic argument payloads, 4,096 tool results with 1,720-byte public synthetic text, and one matching active user exclusion control.

Read `search-bench.mjs`. It opens the journal through native SessionManager and discovers the production extension through native `discoverAndLoadExtensions`. Each fresh process loads the same data, awaits the registered history tool executor, consumes and validates exact returned page lines, skipped counts, cursors and output hashes, and verifies source size and mtime did not change. No provider is called. The timed region starts immediately before the registered executor call, after loading/registration/GC, and ends after its promise resolves. It includes projection, branch search, cursor/ranking, token admission and rendering. Turn reservation reset precedes timing. Usage is a known 1,000/400,000 tokens on both sides, so unrelated SDK usage estimation and issue 96 tool-schema estimation are not added to this scoped search measurement. No standalone helper speedup is claimed.

Each process runs a no-match search first, a matching page second, and its continuation third. Every side has identical cache/warmup order, tool configuration and flags. Forced GC precedes and follows each case on both sides. The timed samples have no profiler, counter patch, tracing or preservation import.

## Five alternating process pairs

`pairs/` contains the five admitted A/B process pairs in A,B,A,B order. `summary.json` contains every sample and its median/minimum/maximum. Every process exited 0. All 30 requests returned correct outputs with zero errors. Each paired output SHA-256 agrees. The three output lengths are 45, 1,025 and 975 bytes.

| Registered executor | Baseline median [range], ms | Treatment median [range], ms |
| --- | --- | --- |
| No match | 290.933 [278.825, 320.180] | 149.885 [145.624, 156.117] |
| First matching page | 203.181 [195.900, 217.865] | 118.489 [112.568, 126.138] |
| Second matching page | 207.353 [201.507, 223.343] | 109.349 [106.842, 111.861] |

The no-match median is 48.5% lower. The ranges do not overlap. These are complete tool-executor measurements; they exclude session loading and provider latency.

The first attempted five-pair set overlapped an owned Go checker build. It is retained under `pairs-contaminated/` and excluded from claims. At the admitted set's start, `ps` showed no running compiler, only its exited zombies; load average was 0.42 and nproc was 2. The workload was interleaved on the same host. This transcript's command receipts preserve that observation. Initial one-off floor-SDK reproduction and all assertion failures are retained, not substituted for these pairs.

## Memory observations

The median `heapUsed` increase between pre-call GC and executor return was 90,681,792 to 50,554,024 bytes for no-match, 87,570,496 to 53,833,320 bytes for page one, and 85,520,984 to 54,120,136 bytes for page two. These are live-heap observations at the return boundary, affected by any GC during the call. They are not total allocated bytes or a peak-heap measurement. `summary.json` also retains post-GC JS-heap deltas and separate RSS values. Post-GC RSS is process residency, not retained JS heap. No leak or owner-corpus memory-saving claim follows from these observations.

## Limiter and work witness

Separate `work-A/`, `work-B/` and `profile-{A,B}.cpuprofile` runs instrumented native projection calls and JSON stringification of the public synthetic tool arguments. They are excluded from timings. Baseline serializes 8,192 argument objects, representing 52,838,400 payload bytes, on each case. Treatment serializes 4,096 objects, representing 26,419,200 payload bytes. Default no-match native projection calls drop from one to zero; matching page calls remain one. Work, output and error counters prove that the timed call was not a no-op or rejection.

`profiles-summary.json` attributes baseline CPU samples across the three cases to eager `contextVisibility` at 273.384 ms, native `buildSessionProjection` at 18.364 ms, and branch search at 317.133 ms. JSON serialization, string normalization and garbage collection dominate, not I/O, a provider or a load generator. After the change, branch traversal/text matching and its remaining serialization dominate. Removing about one duplicate normalization pass is consistent with about half the no-match work disappearing. This does not remove the full branch scan or promise constant time.

## Commands

The actual script accepts explicit source, SDK, journal, output, and mode paths. After creating detached baseline and treatment source worktrees and symlinking each to the same frozen host dependencies, the admitted pair loop was equivalent to:

```sh
export HOME=/workspace/evidence/issue-102/isolated-home
export PI_CODING_AGENT_DIR="$HOME/agent"
export TMPDIR=/workspace/evidence/issue-102/tmp
export PI_OFFLINE=1 PI_TELEMETRY=0
for i in 1 2 3 4 5; do
  for side in A B; do
    node --expose-gc search-bench.mjs "/workspace/bench-$side" \
      /workspace/hosts/official-1.4.0-frozen/node_modules/@earendil-works/pi-coding-agent/dist/index.js \
      journals/synthetic-v3.jsonl "pairs/$i-$side" timing
  done
done
```

The separate profile/counter calls add `--cpu-prof --cpu-prof-dir=... --cpu-prof-name=profile-A.cpuprofile` and use `work` instead of `timing`. Native regression red/green logs prove unwanted repeated serialization and the all-session snapshot boundary. A same-configured-model independent review found one vacuous replacement-session assertion; the persisted replacement fixture and skipped-count assertion fix it in `visibility-review-fix.log`. Full repository and moving-host qualification results are recorded separately when complete.

## Retention and limits

All evidence is generated public synthetic data or public package/source metadata. No owner corpus, raw owner request log, private session, account cache or installed runtime was accessed. `preserve-journals.mjs` retains later native fixture journals before normal test teardown/rewrite; `retained-journals/manifest.tsv` identifies captured byte content. Early focused native attempts used the repository's normal teardown before this retention import was added; their test logs are retained, but those early temporary journals were not captured. The benchmark journal itself is preserved unchanged. Model admission is separately recorded in `admission.json`, not product documentation. Local compilers were initially unavailable, one Rust prerequisite was missing, and the first Go build timed out; those failed logs are retained and none is a pass. Public GitHub's bundled watcher cannot start because Bun is unavailable, and this guest has no authenticated forge CLI. The supported native GitHub integration owns PR creation and exact-head checks/reviews/thread pagination instead.
