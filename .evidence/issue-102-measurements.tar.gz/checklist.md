# Issue 102 checklist

## Perf issue

1. Capture a baseline trace via the matching control skill. Vet the baseline, and each later number, with the **benchmark-checklist** skill.
2. `how` to ground hypotheses. Don't claim a perf ceiling without running it first.
   - skip: automatic specialist panel. Inspect native APIs and separate profile; escalate only a concrete unresolved design need.
3. Plan the fix from the trace. If it crosses a function boundary, `architect` first. Delegate implementation to a subagent using your configured perf-issue model (default `grok-4.7-xhigh-fast`). Pick each subagent's reasoning level and fast or standard speed for the job, per the Subagents section. Review the diff. Capture a post-fix trace.
   - skip: nested implementation delegation and automatic architect. This isolated code owner implements the assigned issue under the parent program. Pi adapter task-scope override applies.
4. Parse and compare the artifacts (JSON to sqlite, diff). "Inconclusive" or wrong-surface is not a pass. Flag it.
5. Cite the measurement in the PR.
6. Run **Opening a PR**.

## Opening a PR

- [ ] Standalone cleanup, format, inspect diff.
- [ ] Required quality, real SDK and CLI qualification and package gates.
- [ ] Independent coverage, including all actual remote reviewers.
- [ ] Ready PR, concise pstack briefing, immutable public-safe evidence.

## Babysit

Explicitly assigned drive to merge-ready only. Native github tool is the supported forge integration. No merge, auto-merge, deploy or runtime activation. No nested watcher if native exact-head polling provides the required supported capability; record tool limitations honestly. No force-push.

## Task checkpoints

- [x] Verified correlated model admission, recorded separately in admission.json.
- [x] Current origin/main baseline resolved once at admission, 8ac3eed9d6326e31e97ba9a1b7288c7568084777.
- [x] Isolated cloud worktree created on assigned branch.
- [x] Read specified pstack adapter and leaves, repository AGENTS, development and quality guidance.
- [ ] Name data shape and throughput checkpoint after API discovery, before implementation.
- [ ] Prove current-main reachable problem with real registered executor and generated journals.
- [ ] Native API comparison across locked floor, independently resolved latest official and fork.
- [ ] No-match, matching/paginated, branch/context and mutation correctness; five alternating process pairs.
- [ ] Retain raw generated journals and failed attempts outside removed trees.
- [ ] Report exact revisions, checks, limits, reviewer findings and evidence.

Additional how/architect/arena/swarm/no-comments panels are not selected automatically. No alternate-model provider is discovered in the native agents interface; do not claim a diverse-model trail review from same-model agents. Remote enabled reviewers remain required. Only public synthetic data is used.
