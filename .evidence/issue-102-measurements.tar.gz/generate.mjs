import { createWriteStream } from 'node:fs';
import { mkdir, stat, writeFile } from 'node:fs/promises';
import { once } from 'node:events';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
const out = process.argv[2];
await mkdir(out, {recursive:true});
const file = join(out, 'synthetic-v3.jsonl');
const stream = createWriteStream(file);
const date = '2026-10-24T00:00:00.000Z';
let id = 0, parentId = null, entries = 0;
const hash = createHash('sha256');
async function line(value) {
 const text = JSON.stringify(value)+'\n';
 hash.update(text);
 if (!stream.write(text)) await once(stream,'drain');
}
async function entry(value) {
 const next = (++id).toString(16).padStart(8,'0');
 await line({id:next,parentId,timestamp:date,...value});
 parentId=next; entries++;
 return next;
}
await line({type:'session',version:3,id:'10200000-0000-4000-8000-000000000001',timestamp:date,cwd:out});
for(let i=0;i<4096;i++) await entry({type:'message',message:{role:'user',content:`HIST_NEEDLE original ${i}.`,timestamp:i}});
await entry({type:'compaction',summary:'Synthetic archived window.',firstKeptEntryId:null,tokensBefore:100000,details:{posthorse:1}});
const payload = 'Synthetic PUBLIC tool argument 0123456789. '.repeat(150);
const result = 'Synthetic PUBLIC tool result abcdefghijkl. '.repeat(40);
for(let i=0;i<4096;i++) {
 await entry({type:'message',message:{role:'assistant',content:[{type:'toolCall',id:`call-${i}`,name:'synthetic_probe',arguments:{payload,index:i}}],api:'openai-responses',provider:'faux',model:'synthetic',usage:{input:0,output:0,cacheRead:0,cacheWrite:0,totalTokens:0,cost:{input:0,output:0,cacheRead:0,cacheWrite:0,total:0}},stopReason:'toolUse',timestamp:i}});
 await entry({type:'message',message:{role:'toolResult',toolCallId:`call-${i}`,toolName:'synthetic_probe',content:[{type:'text',text:result}],isError:false,timestamp:i}});
}
await entry({type:'message',message:{role:'user',content:'HIST_NEEDLE active exclusion control.',timestamp:99999}});
stream.end();
await once(stream,'finish');
const info={file,bytes:(await stat(file)).size,entries,sha256:hash.digest('hex'),archivedOriginals:4096,activeMessages:8193,toolArgumentBytes:payload.length,toolResultBytes:result.length,headerVersion:3,physicalLines:entries+1};
await writeFile(join(out,'fixture.json'),JSON.stringify(info,null,2)+'\n');
console.log(JSON.stringify(info));
