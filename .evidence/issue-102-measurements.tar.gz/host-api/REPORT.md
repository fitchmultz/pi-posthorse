# Issue 102 native host API verdict

throughput checkpoint: n/a, read-only investigation

## Recommendation

Use lazy authoritative `buildSessionProjection()` and normalize only matching candidate IDs. This is the smallest supported solution for the demonstrated eager active-context text normalization. No production file was edited by this delegate.

The data is one per-search index from a native projected source-entry ID to its native messages. An optional per-search normalized-text cache can reuse work when several candidates refer to the same target. The host remains responsible for selecting branches, compactions, and context edits.

Create the projection only after a matching candidate needs a visibility check. Reuse that projection within the invocation. Recompute it for a later search. Preserve the existing ID lookup, `context_edit.targetId` lookup, reminder exception, message normalization, and substring test.

This avoids projection on a no-match search and avoids normalizing unrelated active payloads on matching searches. Matching searches still construct native projection entries and message arrays once per invocation. Branch scanning still normalizes entries as required by the existing search. These are conclusions about which work is selected, not measured performance claims.

## Why the other public APIs are insufficient

The official and maintained fork APIs have no public single-entry converter that applies active context edits. `projectContextEntry(entry, edit)` is private. The public `sessionEntryToContextMessages(entry)` converts the raw entry only.

`buildContextEntries()` is public on `ReadonlySessionManager` at the 1.3.0 floor and both latest hosts. It selects compaction-aware raw entries. It does not apply omissions or replacements. It can also retain an older compaction entry whose canonical contribution must be empty.

The public free `buildSessionProjection(entries, leafId, byId)` still projects an ancestry path. Selecting a candidate as `leafId` omits later edits and later compactions. Creating a reduced synthetic journal would require extension-owned ancestry, edit, and compaction rules. That would be a custom projection layer, not a native candidate-only API.

`buildSessionContext()` delegates to the full projection and discards entry provenance. The class has this method, but `ReadonlySessionManager` does not include it. It is neither a cheaper replacement nor a way to associate a transformed message with its raw entry.

`getBranch()` selects the active raw ancestry, not the effective context. `getEntry()` is an indexed raw lookup and also returns entries from inactive branches. Neither establishes current visibility.

### Official source evidence

The official 1.3.0 and 1.4.0 session-manager TypeScript source, packaged JavaScript, and declarations are byte-identical. Source-map `sourcesContent` matches the exact release-tag source in both installed packages.

- [Readonly manager methods at official 1.4.0, lines 245 to 262](https://github.com/earendil-works/pi/blob/4a080252f06caf63a525d7873c5d94d3c23887e0/packages/coding-agent/src/core/session-manager.ts#L245-L262).
- [Raw single-entry conversion, lines 435 to 466](https://github.com/earendil-works/pi/blob/4a080252f06caf63a525d7873c5d94d3c23887e0/packages/coding-agent/src/core/session-manager.ts#L435-L466).
- [Raw context selection, lines 468 to 512](https://github.com/earendil-works/pi/blob/4a080252f06caf63a525d7873c5d94d3c23887e0/packages/coding-agent/src/core/session-manager.ts#L468-L512).
- [Private edit-aware conversion and canonical projection, lines 519 to 582](https://github.com/earendil-works/pi/blob/4a080252f06caf63a525d7873c5d94d3c23887e0/packages/coding-agent/src/core/session-manager.ts#L519-L582).
- [Indexed getEntry, lines 1412 to 1414](https://github.com/earendil-works/pi/blob/4a080252f06caf63a525d7873c5d94d3c23887e0/packages/coding-agent/src/core/session-manager.ts#L1412-L1414).
- [Manager branch, context, projection, and lifetime entry copy, lines 1464 to 1522](https://github.com/earendil-works/pi/blob/4a080252f06caf63a525d7873c5d94d3c23887e0/packages/coding-agent/src/core/session-manager.ts#L1464-L1522).
- [Same canonical code at the floor release, lines 519 to 582](https://github.com/earendil-works/pi/blob/71023aec1546d6d677a65669c5665c0927ce0dd0/packages/coding-agent/src/core/session-manager.ts#L519-L582).

### Maintained fork evidence

The inspected fork is exactly `c17adbc400319887c5ab34fce1ed2a59be746da4`, the target supplied at admission. It is a clean detached checkout. Its source declares version `1.4.0`. It is not an installed or qualified fork host.

- [Readonly manager methods, lines 247 to 264](https://github.com/fitchmultz/pi/blob/c17adbc400319887c5ab34fce1ed2a59be746da4/packages/coding-agent/src/core/session-manager.ts#L247-L264).
- [Raw entry conversion and compaction-aware selection, lines 438 to 518](https://github.com/fitchmultz/pi/blob/c17adbc400319887c5ab34fce1ed2a59be746da4/packages/coding-agent/src/core/session-manager.ts#L438-L518).
- [Private edit-aware conversion and canonical projection, lines 525 to 596](https://github.com/fitchmultz/pi/blob/c17adbc400319887c5ab34fce1ed2a59be746da4/packages/coding-agent/src/core/session-manager.ts#L525-L596).
- [Cached active ancestry and manager projection, lines 1520 to 1570](https://github.com/fitchmultz/pi/blob/c17adbc400319887c5ab34fce1ed2a59be746da4/packages/coding-agent/src/core/session-manager.ts#L1520-L1570).

## Native behavior checks

`node /workspace/evidence/issue-102/host-api/native-api-probe.mjs` passed against the actual locked SDK and separately frozen latest official SDK. It imported their actual public entry points. Each child ran with an isolated offline HOME and short temporary root under `/var/tmp`, outside project-marker ancestry and without provider credentials. Sessions existed only in memory. No provider calls were made.

The checks demonstrated five relevant behaviors on each official host.

1. An omission keeps its target in `buildContextEntries()`. Raw single-entry conversion still emits the target. Canonical projection emits no target message. Candidate-leaf projection incorrectly misses the later omission for this purpose.
2. The latest active edit wins through replacement, omission, and restoration.
3. `getEntry()` can return an inactive sibling edit. Current projection ignores that edit after a branch change.
4. An older compaction can remain in raw context entries while contributing no canonical message. Raw single-entry conversion would incorrectly emit its summary.
5. A Posthorse-style compaction with a null kept boundary removes the retired window and retains the boundary and subsequent message.

These are focused API assertions, not the Posthorse native suites or latest-host qualification. The fork behavior was inspected in source only. No fork executable was built or run.

## Correctness details for the minimal change

- Keep `messages.map(seenText).join("\n")` before the current substring comparison. A compaction may own both a system message and a summary.
- Treat an empty normalized string as a present value. The old `includes("")` behavior is true for a present empty string. A truthiness guard would change behavior.
- Index only valid nonempty IDs with nonempty native message arrays, as the existing code does.
- Resolve a `context_edit` candidate through `targetId`, not its own ID.
- Preserve the existing reminder exception before a lazy projection is needed.
- Keep the projection and any text cache local to one invocation. A persistent cache would need invalidation for edits, compaction, appends, branch navigation, session changes, reload, and restore.
- Preserve current-file scoping in `all=true` searches. Same-looking entry IDs from other files are not evidence of visibility in the active session.
- A projection created on the first candidate is a snapshot at that point. It should not be recreated per candidate. If invocation-start snapshot timing across asynchronous archive scans is a separate required contract, that timing needs its own test.

## Exact host identity

Latest official was independently resolved with `npm view @earendil-works/pi-coding-agent@latest version dist gitHead time --json` at `2026-10-24T16:22:41Z`. It returned `1.4.0`. No `gitHead` field was returned. The official tag resolved to `4a080252f06caf63a525d7873c5d94d3c23887e0`. The floor tag resolved to `71023aec1546d6d677a65669c5665c0927ce0dd0`.

Latest coding-agent npm integrity is `sha512-Z41LpZ3yYHSC/UUps6Mr39UMFPwH8elhJBG9DY1P7kuzsE5qSK/6eMj2EHzO5evJRQWLbKSqUMw+4nCNtIyiQg==`. The tarball URL is `https://registry.npmjs.org/@earendil-works/pi-coding-agent/-/pi-coding-agent-1.4.0.tgz`.

Both actual official CLIs ran `--version` successfully in isolated offline homes. The floor printed `1.3.0`. Latest printed `1.4.0`. Their index and CLI entry bytes happen to match, so those hashes alone do not distinguish these distributions. The versioned manifests, companion graph, release lock, npm integrity, and actual CLI output establish identity together.

The packaged session-manager JavaScript SHA-256 is `046b6a1109ac3f0ed893bb85bf0648709362fa926a5da75761216cf2fcf9d926` on both official hosts. The declarations SHA-256 is `2288b69c82272311dc877da61ff2057bb04df49038ddef7eef6c8753c09f5313`. Their original TypeScript SHA-256 is `450d82c529933214e088b8422f00061815e617f352f6c834689787a314064bff`.

### Companion graph

The floor physically resolves `pi-agent-core`, `pi-ai`, `pi-codemode`, `pi-mcp`, `pi-tui`, and `pi-telemetry` at `1.3.0`. TypeBox resolves at `1.3.27` relative to coding-agent.

The prepared frozen official host physically resolves that same Pi companion set at `1.4.0`, with TypeBox still `1.3.27`. The pinned automation checked all cohort package metadata, release installer inputs, npm integrity, and the installed graph. Its full runtime lock SHA-256 is `38820ba07480dda5d082fdf1e155c052281b739701ede3c5192c35c35301b22b`. Its runtime graph SHA-256 is `b6735efb7df42e441b014482e566fb84b0f5de464de6d7eec9db780aa149735c`.

The fork source and installer lock declare the 1.4.0 cohort plus `@earendil-works/chord` and `@earendil-works/pi-durable`, with TypeBox `1.3.37`. This is source-lock evidence only. It is not a physically installed fork graph. Do not reuse the official graph for fork qualification. Full declarations and installer entries are retained in `fork-source-graph.json`.

## Relevant changes

The official 1.4.0 changelog changes compaction and branch summary output limits and fixes instructions for split-turn compaction. It does not add a candidate-only projection API. Direct package comparison establishes that session-manager implementation and declarations did not change between the floor and latest release. [Official changelog](https://github.com/earendil-works/pi/blob/4a080252f06caf63a525d7873c5d94d3c23887e0/packages/coding-agent/CHANGELOG.md#L3-L65).

Fork commit `dd1e786941ce983f3c17db9616932d70888cbaca` caches active ancestry, compaction-aware raw entries, and context settings. Appends extend the cache, and leaf or entry-list changes rebuild it. Projection objects and messages remain fresh. The optimization removes repeated archived ancestry work but does not remove eager Posthorse text normalization. [Fork change](https://github.com/fitchmultz/pi/commit/dd1e786941ce983f3c17db9616932d70888cbaca), [maintained fork contract](https://github.com/fitchmultz/pi/blob/c17adbc400319887c5ab34fce1ed2a59be746da4/FORK.md#L108-L109).

## Preparation and remaining gates

The automation checkout is pinned to `54c687228d840506555801b9db038373e697d901` at `/workspace/hosts/automation-54c68722`.

`/workspace/hosts/official-1.4.0-frozen` is a prepared host made with its `prepareHost()` helper and the official release installer lock. An earlier ordinary install is retained at `/workspace/hosts/official-1.4.0` for independent package inspection. Prefer the frozen host for continued diagnostics.

The first isolated preparation attempt failed certificate validation before installation. The retained log records `SELF_SIGNED_CERT_IN_CHAIN`. The next attempt used Node's system CA store through `NODE_OPTIONS=--use-system-ca` and passed. TLS validation was not disabled.

The fork source remains at `/workspace/hosts/fork-c17adbc4`. It has no compiled `dist`, generated declarations, tarball receipt, or actual CLI version output. No heavy compile was started while the root measured and prepared its quality engine.

The automation's full qualification requires selected-host typechecking and contracts, Git-consumer loading, a packed npm-consumer installation, resource checks, and actual CLI probes. Those gates were not run here. [Qualification phases](https://github.com/fitchmultz/.github/blob/54c687228d840506555801b9db038373e697d901/scripts/qualify.mjs#L66-L120).

Fork packing requires its offline build, native package artifacts, exact clean source, source installer lock, and a receipt. Source inspection cannot substitute for those steps. [Fork packing requirements](https://github.com/fitchmultz/.github/blob/54c687228d840506555801b9db038373e697d901/scripts/pack-fork.mjs#L6-L66).

No `npm run verify`, Posthorse qualification, package publication, PR operation, live runtime activation, private session access, credential access, or local-device access was performed by this delegate.

## Evidence files

- `admission-latest-official.log` contains the independent latest npm resolution.
- `locked-package-registry.json` contains floor npm metadata.
- `session-api-identities.log` contains exact source and packaged API hashes.
- `source-map-identity.log` verifies packaged source maps against exact release sources.
- `native-api-probe.json` and `native-api-probe.log` contain actual official CLI output, resolved companion paths, and synthetic API results.
- `native-api-probe.mjs` and `native-api-cases.mjs` reproduce those focused observations.
- `official-frozen-identity.json` contains the prepared latest host's full graph and installer provenance.
- `prepare-official.log` and `prepare-official-system-ca.log` preserve the failed and successful preparation attempts.
- `fork-source-identity.log`, `fork-source-graph.json`, and `fork-boundary-optimization.log` contain pinned fork evidence.

The Laziness Protocol favored the local deferred-projection change over a custom visibility engine. Prove It Works required actual installed SDK assertions, CLI output, and source-map comparison. Model the Domain kept observations organized as host and case records, without an alternative implementation of host semantics.
