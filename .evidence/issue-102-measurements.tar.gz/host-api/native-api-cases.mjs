import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";
const [index, cwd] = process.argv.slice(2);
const sdk = await import(pathToFileURL(index));
const make = () => sdk.SessionManager.inMemory(cwd);
const addUser = (manager, text) => manager.appendMessage({ role: "user", content: text, timestamp: 1 });
const contribution = (manager, id) => manager.buildSessionProjection().entries.find((entry) => entry.sourceEntry.id === id)?.messages;
const snapshots = [];
{
  const manager = make();
  const target = addUser(manager, "synthetic original");
  const edit = manager.appendContextEdit(target, null);
  assert(manager.buildContextEntries().some((entry) => entry.id === target));
  assert.equal(sdk.sessionEntryToContextMessages(manager.getEntry(target)).length, 1);
  assert.deepEqual(contribution(manager, target), []);
  const historical = sdk.buildSessionProjection(manager.getEntries(), target);
  assert.equal(historical.entries.find((entry) => entry.sourceEntry.id === target).messages.length, 1);
  snapshots.push({ case: "omission-needs-later-edit", targetRetainedByBuildContextEntries: true, rawEntryMessageCount: 1, currentProjectedMessageCount: 0, candidateLeafMessageCount: 1, editOnBranch: manager.getBranch().some((entry) => entry.id === edit) });
}
{
  const manager = make();
  const target = addUser(manager, "synthetic original");
  manager.appendContextEdit(target, { content: "synthetic replacement" });
  assert.equal(contribution(manager, target)[0].content, "synthetic replacement");
  manager.appendContextEdit(target, null);
  assert.deepEqual(contribution(manager, target), []);
  manager.appendContextEdit(target, { content: "synthetic restored" });
  assert.equal(contribution(manager, target)[0].content, "synthetic restored");
  snapshots.push({ case: "latest-active-context-edit-wins", replacementThenOmissionThenRestore: "passed" });
}
{
  const manager = make();
  const target = addUser(manager, "synthetic shared ancestor");
  const discardedEdit = manager.appendContextEdit(target, null);
  manager.branch(target);
  addUser(manager, "synthetic sibling");
  assert(manager.getEntry(discardedEdit));
  assert(!manager.getBranch().some((entry) => entry.id === discardedEdit));
  assert.equal(contribution(manager, target)[0].content, "synthetic shared ancestor");
  snapshots.push({ case: "branch-local-edit", indexedOffBranchEditExists: true, activeProjectionIgnoresIt: true });
}
{
  const manager = make();
  const target = addUser(manager, "synthetic retained");
  const older = manager.appendCompaction("synthetic older summary", target, 1);
  addUser(manager, "synthetic tail");
  const newer = manager.appendCompaction("synthetic newer summary", target, 1);
  const active = manager.buildContextEntries();
  assert.equal(active[0].id, newer);
  assert(active.some((entry) => entry.id === older));
  assert(sdk.sessionEntryToContextMessages(manager.getEntry(older)).length > 0);
  assert.deepEqual(contribution(manager, older), []);
  snapshots.push({ case: "retained-older-compaction", olderRetainedByBuildContextEntries: true, olderRawProjectorContributes: true, olderCanonicalProjectionContributes: false });
}
{
  const manager = make();
  const retired = addUser(manager, "synthetic retired window");
  const boundary = manager.appendCompaction("", null, 1, { posthorse: 1 });
  const current = addUser(manager, "synthetic current window");
  const activeIds = manager.buildContextEntries().map((entry) => entry.id);
  assert(!activeIds.includes(retired));
  assert.deepEqual(activeIds, [boundary, current]);
  snapshots.push({ case: "posthorse-null-kept-boundary", retiredEntryExcluded: true, boundaryAndCurrentEntryRetained: true });
}
console.log(JSON.stringify({ syntheticOnly: true, nativeApiAssertions: "passed", cases: snapshots }));
