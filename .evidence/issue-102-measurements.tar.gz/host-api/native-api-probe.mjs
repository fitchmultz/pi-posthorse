import assert from "node:assert/strict";
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { dirname, join } from "node:path";
import { findPackageJSON } from "node:module";
import { pathToFileURL } from "node:url";
import { createHash } from "node:crypto";
import { isolatedEnvironment } from "/workspace/hosts/automation-54c68722/scripts/common.mjs";
const evidence = "/workspace/evidence/issue-102/host-api";
const hosts = [
  ["floor", "/workspace/issue-102/node_modules/@earendil-works/pi-coding-agent"],
  ["official-latest-frozen", "/workspace/hosts/official-1.4.0-frozen/node_modules/@earendil-works/pi-coding-agent"],
];
const hash = (path) => createHash("sha256").update(readFileSync(path)).digest("hex");
const reports = [];
for (const [name, packageDir] of hosts) {
  const root = mkdtempSync("/var/tmp/ha-");
  const env = isolatedEnvironment(root);
  const cwd = join(root, "project");
  mkdirSync(cwd);
  const manifest = JSON.parse(readFileSync(join(packageDir, "package.json"), "utf8"));
  const index = join(packageDir, "dist/index.js");
  const cli = join(packageDir, manifest.bin.pi);
  const companions = {};
  const pending = [manifest];
  for (const pkg of pending) {
    for (const dependency of Object.keys(pkg.dependencies ?? {})) {
      if ((!dependency.startsWith("@earendil-works/") && dependency !== "typebox") || companions[dependency]) continue;
      const file = findPackageJSON(dependency, pathToFileURL(index));
      const selected = JSON.parse(readFileSync(file, "utf8"));
      companions[dependency] = { version: selected.version, packageDir: dirname(file), manifestSha256: hash(file) };
      pending.push(selected);
    }
  }
  const version = spawnSync(process.execPath, [cli, "--version"], { cwd, env, encoding: "utf8", timeout: 15000 });
  assert.equal(version.status, 0, version.stderr);
  assert.equal(version.stdout.trim(), manifest.version);
  const child = spawnSync(process.execPath, [join(evidence, "native-api-cases.mjs"), index, cwd], { cwd, env, encoding: "utf8", timeout: 15000 });
  assert.equal(child.status, 0, child.stderr);
  reports.push({ name, packageDir, version: manifest.version, indexSha256: hash(index), cliSha256: hash(cli), declarationsSha256: hash(join(packageDir, "dist/core/session-manager.d.ts")), cliVersion: version.stdout.trim(), cliStderr: version.stderr, companions, nativeProbe: JSON.parse(child.stdout) });
}
writeFileSync(join(evidence, "native-api-probe.json"), JSON.stringify(reports, null, 2) + "\n");
console.log(JSON.stringify(reports, null, 2));
