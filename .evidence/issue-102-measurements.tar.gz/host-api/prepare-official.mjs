import { mkdtempSync, writeFileSync } from "node:fs";
import { isolatedEnvironment } from "/workspace/hosts/automation-54c68722/scripts/common.mjs";
import { prepareHost } from "/workspace/hosts/automation-54c68722/scripts/hosts.mjs";
const root = mkdtempSync("/var/tmp/ha-");
const env = isolatedEnvironment(root);
const host = await prepareHost("/workspace/hosts/official-1.4.0-frozen", "official", "1.4.0", env);
writeFileSync("/workspace/evidence/issue-102/host-api/official-frozen-identity.json", JSON.stringify({ preparationOnly: true, isolationRoot: root, host }, null, 2) + "\n");
console.log("Prepared official host only. No extension qualification gates were run.");
