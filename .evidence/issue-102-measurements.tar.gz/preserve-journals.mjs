import fs from 'node:fs';
import { createHash } from 'node:crypto';
import { syncBuiltinESMExports } from 'node:module';
import { join, resolve } from 'node:path';
const destination = '/workspace/evidence/issue-102/retained-journals';
fs.mkdirSync(destination,{recursive:true});
const originalRm=fs.rmSync, originalAsyncRm=fs.promises.rm, originalWrite=fs.writeFileSync;
function allowed(path) {
 const value=resolve(String(path));
 return value.startsWith('/workspace/evidence/issue-102/tmp/') || value.startsWith('/var/tmp/pc-') || value.startsWith('/tmp/pc-');
}
function capture(path) {
 if(!allowed(path) || !fs.existsSync(path)) return;
 const info=fs.lstatSync(path);
 if(info.isSymbolicLink()) return;
 if(info.isDirectory()) {
  for(const child of fs.readdirSync(path)) capture(join(String(path),child));
 } else if(String(path).endsWith('.jsonl')) {
  const bytes=fs.readFileSync(path);
  const hash=createHash('sha256').update(bytes).digest('hex');
  const file=join(destination,hash+'.jsonl');
  if(!fs.existsSync(file)) originalWrite(file,bytes);
  fs.appendFileSync(join(destination,'manifest.tsv'),`${new Date().toISOString()}\t${path}\t${hash}\t${bytes.length}\n`);
 }
}
fs.rmSync=function(path,...args){capture(path);return originalRm(path,...args);};
fs.promises.rm=async function(path,...args){capture(path);return originalAsyncRm(path,...args);};
fs.writeFileSync=function(path,...args){if(String(path).endsWith('.jsonl')) capture(path);return originalWrite(path,...args);};
syncBuiltinESMExports();
