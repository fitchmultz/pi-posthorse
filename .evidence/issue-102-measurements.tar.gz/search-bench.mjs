import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { performance } from 'node:perf_hooks';
const [source, sdk, fixture, output, mode='timing'] = process.argv.slice(2);
const {SessionManager,discoverAndLoadExtensions} = await import(pathToFileURL(sdk));
const cwd = resolve(fixture,'..');
const manager = SessionManager.open(fixture, cwd);
assert.equal(manager.getEntries().length,12290);
const {extensions,errors,runtime} = await discoverAndLoadExtensions([resolve(source,'index.ts')],cwd,join(cwd,'agent'));
assert.deepEqual(errors,[]);
assert.equal(extensions.length,1);
const extension=extensions[0];
runtime.getSettings=()=>({});
runtime.getAllTools=()=>[...extension.tools.values()].map(t=>t.definition);
runtime.getActiveTools=()=>runtime.getAllTools().map(t=>t.name);
const tool=extension.tools.get('history').definition;
const ctx={cwd,sessionManager:manager,model:{id:'offline',provider:'faux',contextWindow:400000},getContextUsage:()=>({tokens:1000,contextWindow:400000,percent:0.25}),getSystemPrompt:()=> 'Synthetic offline history benchmark.',isProjectTrusted:()=>false,hasUI:false,mode:'print'};
let projections=0,serializations=0,serializedBytes=0;
const projection=manager.buildSessionProjection.bind(manager);
const stringify=JSON.stringify;
if(mode==='work') {
 manager.buildSessionProjection=()=>{projections++;return projection();};
 JSON.stringify=(value,...args)=>{if(value?.payload?.startsWith('Synthetic PUBLIC')){serializations++;serializedBytes+=value.payload.length;}return stringify(value,...args);};
}
async function call(params) {
 for(const handler of extension.handlers.get('turn_start')??[]) await handler({},ctx);
 return tool.execute('synthetic-history',params,undefined,undefined,ctx);
}
const cursor=result=>result.content[0].text.match(/\[More results; continue with cursor "([^"]+)" and the same query\/scope\.\]$/)?.[1];
const cases=[{name:'no-match',params:{op:'search',query:'UNFINDABLE_102_SENTINEL'}},{name:'first-page',params:{op:'search',query:'HIST_NEEDLE',limit:10}},{name:'second-page',params:null}];
let first;
const rows=[];
const beforeStat=statSync(fixture);
for(const item of cases) {
 if(item.params===null) item.params={op:'search',query:'HIST_NEEDLE',limit:10,cursor:cursor(first)};
 assert.ok(item.params.op);
 projections=0;serializations=0;serializedBytes=0;
 globalThis.gc?.();
 const before=process.memoryUsage();
 const start=performance.now();
 const value=await call(item.params);
 const elapsedMs=performance.now()-start;
 const after=process.memoryUsage();
 if(item.name==='first-page') first=value;
 const text=value.content[0].text;
 if(item.name==='no-match') assert.equal(text,'No history matches "UNFINDABLE_102_SENTINEL".');
 else {
  const from=item.name==='first-page'?4095:4085;
  const expected=Array.from({length:10},(_,i)=>`${'2026-10-24T00:00:00.000Z'} [window initial] [${(from-i+1).toString(16).padStart(8,'0')}] [user] HIST_NEEDLE original ${from-i}.`);
  assert.deepEqual(text.split('\n').slice(0,10),expected);
  assert.equal(value.details.skipped,1);
  assert.equal(value.details.more,true);
  assert.ok(cursor(value));
 }
 globalThis.gc?.();
 const postGc=process.memoryUsage();
 rows.push({case:item.name,elapsedMs,heapDeltaBytes:after.heapUsed-before.heapUsed,rssDeltaBytes:after.rss-before.rss,postGcHeapDeltaBytes:postGc.heapUsed-before.heapUsed,postGcRssBytes:postGc.rss,projections,serializations,serializedBytes,outputBytes:Buffer.byteLength(text),outputSha256:createHash('sha256').update(stringify(value)).digest('hex'),errors:0,output:value});
}
JSON.stringify=stringify;
assert.equal(statSync(fixture).size,beforeStat.size);
assert.equal(statSync(fixture).mtimeMs,beforeStat.mtimeMs);
mkdirSync(output,{recursive:true});
writeFileSync(join(output,'result.json'),stringify({source,sdk,node:process.version,platform:process.platform,arch:process.arch,mode,fixtureBytes:beforeStat.size,entries:manager.getEntries().length,rows},null,2));
console.log(stringify(rows.map(({output,...row})=>row)));
